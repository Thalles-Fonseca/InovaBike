# InovaBike

Aplicativo web/mobile demonstrativo de mobilidade elétrica sustentável.

## Proposta

A InovaBike conecta tecnologia, economia sustentável, mobilidade urbana e meio ambiente, oferecendo acesso a bikes elétricas para cicloentregadores e usuários urbanos.

## Arquivos principais

- `InovaBike/inovabike.html`: estrutura das telas.
- `InovaBike/style.css`: identidade visual.
- `InovaBike/script.js`: navegação, bikes, benefícios, QR Code, mapa e simulação de financiamento.
